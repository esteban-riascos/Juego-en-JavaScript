//elementos requeridos//
const start_btn = document.querySelector(".start_btn button");
const instructions_box = document.querySelector(".instructions_box");
const salida_btn = instructions_box.querySelector(".buttons .exit");
const continuar_btn = instructions_box.querySelector(".buttons .restart");
const quiz_box = document.querySelector(".quiz_box");
const timeCount = quiz_box.querySelector(".tiempo .tiempo_seg");
const timeLine = quiz_box.querySelector("header .time_line");

const lista_respuesta = document.querySelector(".lista_respuesta");

//boton de inicio//
start_btn.onclick = ()=>{
    instructions_box.classList.add("activeInfo");
}
//boton salida//
salida_btn.onclick = ()=>{
    instructions_box.classList.remove("activeInfo");
}
continuar_btn.onclick = ()=>{
    instructions_box.classList.remove("activeInfo");
    quiz_box.classList.add("activeQuiz");
    showQuestions(0);
    queCounter(1);
    starTimer(15);
    starTimerLine(0);
}
let que_count = 0;
let que_numb = 1;
let counter;
let timeValue = 15;
let withValue = 0;
let UserScore = 0;


const next_bnt= quiz_box.querySelector(".next_btn");
const result_box = document.querySelector(".result_box");
const restart_quiz = result_box.querySelector(".buttons .exit");
const quit_quiz = result_box.querySelector(".buttons .restart");

// si se hace click en restart
restart_quiz.onclick = () => {
    window.location.reload();   
}
 //avanzar siguiente pregunta//
 next_bnt.onclick =()=>{
     if(que_count < questions.length - 1){  // si el recuento de las preguntas, es menor que el total//
        que_count++;
        que_numb++;
        showQuestions(que_count); //se llama a la funcion show//
        queCounter(que_numb); //pasando el valor de que_numb a queCounter//
        clearInterval(counter);
        starTimer(timeValue); //llamada a la funcion time value//
        clearInterval(counterLine);
        starTimerLine(withValue); // cambiar a tiempo restante// 
        next_bnt.style.display = "none"; //oculta el boton hasta marcar la respuesta//
     }else{
         console.log("Fin del juego");
         showResultBox();
     }
 }


//opciones de preguntas//
function showQuestions(index){
    const que_text = document.querySelector(".que_text");
    let que_tag = '<span>'+ questions[index].numb + " " + questions[index].question +'</span>';
    let option_tag = '<div class="opcion"><span>'+ questions[index].options[0] +'</span></div>'
    + '<div class="opcion"><span>'+ questions[index].options[1] +'</span></div>'
    + '<div class="opcion"><span>'+ questions[index].options[2] +'</span></div>'
    + '<div class="opcion"><span>'+ questions[index].options[3] +'</span></div>';
    que_text.innerHTML = que_tag; //agregando una nueva etiqueta span dentro de que_tag//
    lista_respuesta.innerHTML = option_tag; 
    que_text.innerHTML = que_tag;
    lista_respuesta.innerHTML = option_tag;
    const option = lista_respuesta.querySelectorAll(".opcion");
    //establecer el atributo onclick a todas las opciones disponibles//
    for(i=0; i < option.length; i++){
        option[i].setAttribute("onclick", "optionSelected(this)");
    }
}
//incos de respuesta correcta e incorrecta//
let tickIcon = '<div class="icon tick"><i class="fas fa-check"></i></div>';
let crossIcon = '<div class="icon cross"><i class="fas fa-times"></i></div>';
//lógica para determinar la respuesta correcta//
//condicionales para derminar los colores para correcta e incorrecta//
function optionSelected(answer){
    clearInterval(counter);
    clearInterval(counterLine);
    let userAns = answer.textContent;
    let correctAns = questions[que_count].aswer;
    let allOptions = lista_respuesta.children.length;

//mostrar iconos para respuesta//
    if(userAns == correctAns){
        UserScore += 1;
        console.log(UserScore);
        answer.classList.add("correct");
        console.log ("Respuesta correcta");
        answer.insertAdjacentHTML("beforeend", tickIcon);
    }else{
        answer.classList.add("incorrect");
        console.log ("Respuesta incorrecta");
        answer.insertAdjacentHTML("beforeend", crossIcon);

        // una vez el usuario seleccione la opción incorrecta, este devuelve la correcta//
        for(i=0; i < allOptions; i++) {
            if(lista_respuesta.children[i].textContent==correctAns){
               lista_respuesta.children[i].setAttribute("class", "opcion correct"); 
               lista_respuesta.children[i].insertAdjacentHTML("beforeend", tickIcon);
            }
            
        }
    }
   //Una vez que el usuario selecciona una opción y luego deshabilita todas las opciones//
    for (let i = 0; i < allOptions; i++) {
         lista_respuesta.children[i].classList.add("diseabled");
    }
    next_bnt.style.display = "block"; //oculta el boton hasta que se seleccione una respuesta//
}
function showResultBox(){
    instructions_box.classList.remove("activeInfo");
    quiz_box.classList.remove("activeQuiz"); //mostrar resultado//
    result_box.classList.add("activeResult");
    const scoreText = result_box.querySelector(".score_text");
    //condicional para resultados, felicitacion o no//
    if (UserScore >3) {
        let scoreTag ='<span>Muy bien, tienes <p>'+ UserScore +' respuestas </p> de <p>'+ questions.length +'</p></span>';
        scoreText.innerHTML = scoreTag;
    }
    else if (UserScore >1) {
        let scoreTag ='<span>Lo siento, solo tienes <p>'+ UserScore +' respuestas </p> de <p>'+ questions.length +'</p></span>';
        scoreText.innerHTML = scoreTag;
    }
    else {
        let scoreTag ='<span>Lo siento, solo tienes <p>'+ UserScore +' respuestas </p> de <p>'+ questions.length +'</p></span>';
        scoreText.innerHTML = scoreTag;
    }
}
function starTimer(time){
    counter = setInterval(tiempo, 1000);
    function tiempo(){
        timeCount.textContent= time;
        time --;
        if (time < 9){ //adcionar 00 al contador de tiempo//
            let addZero=timeCount.textContent;
            timeCount.textContent = "0" + addZero;
        }
        if(time < 0){
            clearInterval(counter);
            timeCount.textContent= "00";
        }

    }
}

//mostrar el resultado//
function starTimerLine(time){
    counterLine= setInterval(tiempo, 40);
    function tiempo(){
        time += 1;
        timeLine.style.width = time + "px"; //aumentando el ancho de time_line con px por valor de tiempo//
        if (time > 400){ // valor del width//
            clearInterval(counterLine);
        }

    }
}
//una vez que el usuario selecciona, desactivo todas las opciones//
function queCounter(index){
    const bottom_ques_counter = quiz_box.querySelector(".total_que"); 
    let totalQuesCountTag = '<span><p> '+ index +'</p><p>de</p><p>'+ questions.length +'</p>preguntas</span>';
    bottom_ques_counter.innerHTML = totalQuesCountTag;
}