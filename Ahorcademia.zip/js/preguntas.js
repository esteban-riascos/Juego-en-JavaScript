//array de preguntas//
let questions = [
     {   
         numb:1,
         question: "Calcula la suma algebraica 50a ÷ (-5)",
         aswer: "-10a",
         options: [
             
               "-6a",
               "-10a",
               "-12a",
               "-15a",     
         ]
     },

     {   
        numb:2,
        question: "Calcula la suma algebraica 36k ÷ 4 : ",
        aswer: "9k",
        options: [
            
              "15k",
              "14k",
              "12k",
              "9k",     
        ]
    },
    {   
        numb:3,
        question: "Simplifica: -8l + 2k - 4k + 4l",
        aswer:  "-2k -4l",
        options: [
            
              "-2k -4l",
              "-10k - 8l",
              "-7k - 12l",
              "4k + 12l",     
        ]
    },
    {   
        numb:4,
        question: "Simplifica: 4l - 4k - 6k + 3l",
        aswer:  "2k + 7l",
        options: [
            
              "5k - 1",
              "2k + 7l",
              "-3k + 4l",
              "3k + 1",     
        ]
    },
    {   
        numb:5,
        question: "Resolver: -6x-7-3=-3x-2x+1",
        aswer:  "x = -11",
        options: [
            
              "x = -12",
              "x = -10",
              "x = -11",
              "x = -9",     
        ]
    },
];